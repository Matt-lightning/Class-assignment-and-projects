#include <iostream>

using namespace std;

class MyDynamicArray {
    private:
        int size, capacity, error;
        int *a;
    public:
        MyDynamicArray() {
           capacity = 2;
           size = 0;
           error = 0;
           a = new int[capacity];
        }
        MyDynamicArray(int s) {
            /* Your code goes here */
        }
        ~MyDynamicArray() {
            /* Your code goes here */
        }
        int& operator[](int i){
            /* Your code goes here */
        }
        void add(int v) {
            /* Your code goes here */
        }
        void del() {
            /* Your code goes here */
        }
        int length() {
            return size;
        }
        void clear() {
           /* Your code goes here */
        }
        MyDynamicArray& operator=(const MyDynamicArray& src) {
           /* Your code goes here */
        }
        
        MyDynamicArray(const MyDynamicArray & src) {
           /* Your code goes here */
        }
};

