#include <iostream>
#include <string>

#include "p3.h"

using namespace std;

Person::Person()
{
    this->height = 0;
    this->weight = 0;
    this->nextHeight = nullptr;
    this->nextWeight = nullptr;
}

Person::Person(string first, string last, int height, int weight)
{
    this->first = first;
    this->last = last;
    this->height = height;
    this->weight = weight;
    this->nextHeight = nullptr;
    this->nextWeight = nullptr;
}

PersonList::PersonList()
{
    this->size = 0;
    this->headHeightList = nullptr;
    this->headWeightList = nullptr;
}

int PersonList::getSize()
{
    return size;
}

void PersonList::printByHeight(ostream &os)
{

}

void PersonList::printByWeight(ostream &os)
{

}

bool PersonList::exists(string first, string last)
{
    return false;
}

int PersonList::getHeight(string first, string last) {
    return -1;
}

int PersonList::getWeight(string first, string last) {
    return -1;
}

bool PersonList::add(string first, string last, int height, int weight)
{
    if (this->exists(first, last))
    {
        return false;
    }
    Person *p = new Person(first, last, height, weight);

	// add it to "headHeightList"
	p->nextHeight = this->headHeightList;
	this->headHeightList = p; 

	// add it to "headWeightList"
	p->nextWeight = this->headWeightList;
	this->headWeightList = p; 

	return true;
}

bool PersonList::remove(string first, string last)
{
    return false;
}

bool PersonList::updateName(string first, string last, string newFirst, string newLast)
{
    return false;
}

bool PersonList::updateHeight(string first, string last, int height)
{
    return false;
}

bool PersonList::updateWeight(string first, string last, int weight)
{
    return false;
}

PersonList::~PersonList()
{
    
}

PersonList::PersonList(const PersonList &src)
{
    
}

const PersonList &PersonList::operator=(const PersonList &src)
{
    return *this;
}
